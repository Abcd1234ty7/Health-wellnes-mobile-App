package com.example.finalapplication2024;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Create the main LinearLayout
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(16, 16, 16, 16);
        mainLayout.setGravity(Gravity.CENTER);

        // Set the background image
        mainLayout.setBackgroundResource(R.drawable.background); // Replace with your image file name

        // Sign-in TextView
        TextView signInTitle = new TextView(this);
        signInTitle.setText("Sign in or create an account");
        signInTitle.setTextSize(20);
        signInTitle.setTextColor(Color.BLACK);
        signInTitle.setGravity(Gravity.CENTER);
        signInTitle.setPadding(0, 0, 0, 20);
        signInTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        mainLayout.addView(signInTitle);

        // Email input
        EditText emailInput = new EditText(this);
        emailInput.setHint("Email");
        emailInput.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        emailInput.setPadding(12, 12, 12, 12);
        emailInput.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        emailInput.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
        mainLayout.addView(emailInput);

        // Password input
        EditText passwordInput = new EditText(this);
        passwordInput.setHint("Password");
        passwordInput.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setPadding(12, 12, 12, 12);
        passwordInput.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        passwordInput.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
        mainLayout.addView(passwordInput);

        // Continue with Apple Button
        Button continueWithApple = new Button(this);
        continueWithApple.setText("Continue with Apple");
        continueWithApple.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
        continueWithApple.setTextColor(Color.WHITE);
        continueWithApple.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(continueWithApple);

        // Continue with Google Button
        Button continueWithGoogle = new Button(this);
        continueWithGoogle.setText("Continue with Google");
        continueWithGoogle.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
        continueWithGoogle.setTextColor(Color.WHITE);
        continueWithGoogle.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(continueWithGoogle);

        // Set OnClickListener to display an error message when clicked
        continueWithGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Error: Unable to continue with Google at the moment.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Continue with Facebook Button
        Button continueWithFacebook = new Button(this);
        continueWithFacebook.setText("Continue with Facebook");
        continueWithFacebook.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
        continueWithFacebook.setTextColor(Color.WHITE);
        continueWithFacebook.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(continueWithFacebook);

        // Create Account link TextView
        TextView createAccount = new TextView(this);
        createAccount.setText("Create Account");
        createAccount.setTextColor(getResources().getColor(android.R.color.holo_blue_light));
        createAccount.setGravity(Gravity.CENTER);
        createAccount.setPadding(0, 20, 0, 20);
        mainLayout.addView(createAccount);

        // Add OnClickListener for Create Account TextView with email validation
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailInput.getText().toString();
                String password = passwordInput.getText().toString();

                // Check if email contains an '@' symbol
                if (!email.contains("@")) {
                    Toast.makeText(MainActivity.this, "Invalid email, please enter a correct email.",
                            Toast.LENGTH_SHORT).show();
                    return; // Stop further execution
                }

                com.example.finalapplication2024.DatabaseHelper dbHelper = new com.example.finalapplication2024.DatabaseHelper(MainActivity.this);
                boolean isInserted = dbHelper.addUser(email, password);

                if (isInserted) {
                    Toast.makeText(MainActivity.this, "Data added successfully", Toast.LENGTH_SHORT).show();
                    // Navigate to LoginActivity
                    Intent intent = new Intent(MainActivity.this, login.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Error adding data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Terms and Privacy Policy TextView
        TextView termsPolicy = new TextView(this);
        termsPolicy.setText("By continuing, you agree to our Terms of Service and Privacy Policy.");
        termsPolicy.setTextSize(12);
        termsPolicy.setTextColor(getResources().getColor(android.R.color.darker_gray));
        termsPolicy.setGravity(Gravity.CENTER);
        mainLayout.addView(termsPolicy);

        // Set the layout as the main content view
        setContentView(mainLayout);
    }
}
