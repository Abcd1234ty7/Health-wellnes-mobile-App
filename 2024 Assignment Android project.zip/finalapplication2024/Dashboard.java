package com.example.finalapplication2024;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Dashboard extends AppCompatActivity {

    private TextView stepsValue, distanceValue, caloriesValue, activeMinutesValue, goalProgressText;
    private ProgressBar goalProgressBar;
    private Button logMealButton, workoutButton, profileButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize UI components
        stepsValue = findViewById(R.id.stepsValue);
        distanceValue = findViewById(R.id.distanceValue);
        caloriesValue = findViewById(R.id.caloriesValue);
        activeMinutesValue = findViewById(R.id.activeMinutesValue);
        goalProgressText = findViewById(R.id.goalProgressText);
        goalProgressBar = findViewById(R.id.goalProgressBar);

        logMealButton = findViewById(R.id.homeButton);  // Renamed to "logMealButton" in code
        workoutButton = findViewById(R.id.settingsButton);  // Renamed to "workoutButton" in code
        profileButton = findViewById(R.id.profileButton);

        // Set button text to new names
        logMealButton.setText("Log Meal");
        workoutButton.setText("Workouts");

        // Sample data population
        setData("2,345", "1.2 mi", "78.5", "45", 60);

        // Button click listeners
        logMealButton.setOnClickListener(view -> {
            // Intent to launch LogMeal activity
            Intent intent = new Intent(Dashboard.this, logmeal.class);
            startActivity(intent);
        });

        workoutButton.setOnClickListener(view -> {
            //  Navigate to WorkoutList activity
            Intent intent = new Intent(Dashboard.this, workout.class);
            startActivity(intent);
        });

        // Profile button click listener to open ProfileActivity
        profileButton.setOnClickListener(view -> {
            Intent intent = new Intent(Dashboard.this, Profile.class);
            startActivity(intent);
        });
    }

    // Method to set data on UI components
    private void setData(String steps, String distance, String calories, String activeMinutes, int progress) {
        stepsValue.setText(steps);
        distanceValue.setText(distance);
        caloriesValue.setText(calories);
        activeMinutesValue.setText(activeMinutes);

        // Update progress bar and text
        goalProgressBar.setProgress(progress);
        goalProgressText.setText(progress + "% of Goal Achieved");
    }
}