package com.example.finalapplication2024;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class workout extends AppCompatActivity {

    // Define UI components
    private TextView title, durationValue, caloriesValue;
    private Button selectWorkoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout); // Ensure XML layout is named "activity_workout.xml"

        // Initialize UI components
        title = findViewById(R.id.title);
        durationValue = findViewById(R.id.duration_value);
        caloriesValue = findViewById(R.id.calories_value);
        selectWorkoutButton = findViewById(R.id.select_workout_button);

        // Set title text
        title.setText("Workout Summary");

        // Set workout details
        durationValue.setText("5 min - 10 min");
        caloriesValue.setText("100-1000 calories burned per exercise");

        // Add click listener to button
        selectWorkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start Exercises activity when button is clicked
                Intent intent = new Intent(workout.this, list2.class);
                startActivity(intent);
            }
        });
    }
}
