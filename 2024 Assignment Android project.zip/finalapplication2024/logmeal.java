package com.example.finalapplication2024;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class logmeal extends AppCompatActivity {

    private EditText foodInput, quantityInput;
    private Button addFoodButton, finishButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logmeal);


        // Initialize UI

        foodInput = findViewById(R.id.foodInput);
        quantityInput = findViewById(R.id.quantityInput);
        addFoodButton = findViewById(R.id.addFoodButton);
        finishButton = findViewById(R.id.finishButton);

        // Set click listeners for buttons
        addFoodButton.setOnClickListener(v -> {
            String foodName = foodInput.getText().toString().trim();
            String quantity = quantityInput.getText().toString().trim();

            // Add logic to process food and quantity (e.g., save to database)
            Toast.makeText(logmeal.this, "Food added successfully!", Toast.LENGTH_SHORT).show();

            // Clear the input fields
            foodInput.setText("");
            quantityInput.setText("");
        });

        finishButton.setOnClickListener(v -> {
            // Navigate back to Dashboard activity (replace with your actual navigation logic)
            Intent intent = new Intent(logmeal.this, Dashboard.class); // Replace with your DashboardActivity class
            startActivity(intent);
            finish();
        });
    }
}