package com.example.finalapplication2024;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Profile extends AppCompatActivity {

    private EditText weightValue;
    private EditText heightValue;
    private EditText activityLevelValue;
    private EditText goalValue;
    private Button saveProfileButton;
    private ImageView closeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile); // replace with your XML file name

        // Initialize Views
        weightValue = findViewById(R.id.weightValue);
        heightValue = findViewById(R.id.heightValue);
        activityLevelValue = findViewById(R.id.activityLevelValue);
        goalValue = findViewById(R.id.goalValue);
        saveProfileButton = findViewById(R.id.saveProfileButton);
        closeButton = findViewById(R.id.closeButton);

        // Set up Save Button click event
        saveProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get values from EditText fields
                String weight = weightValue.getText().toString();
                String height = heightValue.getText().toString();
                String activityLevel = activityLevelValue.getText().toString();
                String goal = goalValue.getText().toString();

                // Check if any field is empty
                if (weight.isEmpty() || height.isEmpty() || activityLevel.isEmpty() || goal.isEmpty()) {
                    Toast.makeText(Profile.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Process the input (e.g., save to a database or shared preferences)
                    // Display a toast message
                    Toast.makeText(Profile.this, "Profile saved successfully!", Toast.LENGTH_SHORT).show();

                    // Navigate to the Dashboard activity
                    Intent intent = new Intent(Profile.this, Dashboard.class);
                    startActivity(intent);
                }
            }
        });

        // Set up Close Button click event
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close the activity
                finish();
            }
        });
    }
}