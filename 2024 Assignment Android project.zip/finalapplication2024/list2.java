package com.example.finalapplication2024;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class list2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list2); // Make sure this matches your XML file name

        // Find each TextView by its ID
        TextView abExercisesLink = findViewById(R.id.linkAbExercises);
        TextView squatsLink = findViewById(R.id.linkSquats);
        TextView stretchesLink = findViewById(R.id.linkStretches);
        TextView supplementsLink = findViewById(R.id.linkSupplements);

        // Set onClickListeners to open URLs
        abExercisesLink.setOnClickListener(v -> openUrl("https://www.webmd.com/fitness-exercise/best-exercises-abs-general")); // Replace with actual URL
        squatsLink.setOnClickListener(v -> openUrl("https://www.healthline.com/health/squat-variations#bodyweight-squats")); // Replace with actual URL
        stretchesLink.setOnClickListener(v -> openUrl("https://www.webmd.com/fitness-exercise/ss/slideshow-stretches-to-get-loose")); // Replace with actual URL
        supplementsLink.setOnClickListener(v -> openUrl("https://www.wellnesswarehouse.com/clean-supplements?gad_source=1&gclid=Cj0KCQiA0MG5BhD1ARIsAEcZtwRrVi1UBZw-adeAZnV8yTJB_kKu4rx06urAd_cuQZfpesOrpp91OBwaAh4XEALw_wcB")); // Replace with actual URL
    }

    // Method to open a URL in the default browser
    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}
