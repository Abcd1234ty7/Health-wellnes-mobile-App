package com.example.finalapplication2024;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set up the parent LinearLayout
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setBackgroundResource(R.drawable.background3);

        // Add buttons
        linearLayout.addView(createButton("Ab Exercises", 1, true));
        linearLayout.addView(createButton("Squat Exercises", 2, false));
        linearLayout.addView(createButton("Stretch Exercises", 3, false));
        linearLayout.addView(createButton("Diet", 4, false));
        linearLayout.addView(createButton("Supplements and Welfare", 5, false));

        // Set the LinearLayout as the content view
        setContentView(linearLayout);
    }

    private Button createButton(String text, int id, boolean isFirstButton) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(16);
        button.setTypeface(button.getTypeface(), android.graphics.Typeface.BOLD);
        button.setBackgroundColor(Color.parseColor("#4CAF50"));

        // Set a unique ID directly
        button.setId(id);

        // Apply layout parameters with margins
        LinearLayout.LayoutParams params = createLayoutParams(isFirstButton);
        button.setLayoutParams(params);

        return button;
    }

    private LinearLayout.LayoutParams createLayoutParams(boolean isFirstButton) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, isFirstButton ? 24 : 8, 0, 16);
        return params;
    }
}
