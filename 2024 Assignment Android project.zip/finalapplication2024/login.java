package com.example.finalapplication2024;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Root LinearLayout setup
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);
        linearLayout.setPadding(24, 24, 24, 24);

        // Set the background image
        linearLayout.setBackgroundResource(R.drawable.background); // Replace "background" with your actual image file name in the drawable folder

        // Welcome Text
        TextView welcomeText = new TextView(this);
        welcomeText.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        welcomeText.setText("Welcome User");
        welcomeText.setTextColor(Color.BLACK);
        welcomeText.setTextSize(24);
        welcomeText.setTypeface(null, android.graphics.Typeface.BOLD);
        welcomeText.setGravity(Gravity.CENTER);
        ((LinearLayout.LayoutParams) welcomeText.getLayoutParams()).setMargins(0, 0, 0, 32);
        linearLayout.addView(welcomeText);

        // Email Input
        EditText emailInput = new EditText(this);
        LinearLayout.LayoutParams emailLayoutParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        emailLayoutParams.setMargins(0, 0, 0, 16);
        emailInput.setLayoutParams(emailLayoutParams);
        emailInput.setHint("Email");
        emailInput.setPadding(12, 12, 12, 12);
        emailInput.setInputType(InputType.TYPE_CLASS_TEXT);
        emailInput.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
        linearLayout.addView(emailInput);

        // Password Input
        EditText passwordInput = new EditText(this);
        LinearLayout.LayoutParams passwordLayoutParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        passwordLayoutParams.setMargins(0, 0, 0, 16);
        passwordInput.setLayoutParams(passwordLayoutParams);
        passwordInput.setHint("Password");
        passwordInput.setPadding(12, 12, 12, 12);
        passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
        linearLayout.addView(passwordInput);

        // Forgot Password Text
        TextView forgotPassword = new TextView(this);
        forgotPassword.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        forgotPassword.setText("Forgot password?");
        forgotPassword.setTextColor(Color.parseColor("#3b5998"));
        forgotPassword.setGravity(Gravity.CENTER_HORIZONTAL);
        ((LinearLayout.LayoutParams) forgotPassword.getLayoutParams()).setMargins(0, 0, 0, 24);
        linearLayout.addView(forgotPassword);

        // Set up click listener for forgot password text
        forgotPassword.setOnClickListener(v -> {
            // Redirect to ForgotPass activity
            Intent intent = new Intent(login.this, forgotpass.class);
            startActivity(intent);
        });

        // Login Button
        Button loginButton = new Button(this);
        LinearLayout.LayoutParams loginButtonParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        loginButtonParams.setMargins(0, 0, 0, 32);
        loginButton.setLayoutParams(loginButtonParams);
        loginButton.setText("Log in");
        loginButton.setBackgroundColor(Color.parseColor("#0073b1"));
        loginButton.setTextColor(Color.WHITE);
        loginButton.setTextSize(16);
        linearLayout.addView(loginButton);

        // Set up click listener for login button with email validation
        loginButton.setOnClickListener(v -> {
            // Validate input and perform login logic
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Check if email contains an '@' symbol
            if (!email.contains("@")) {
                Toast.makeText(login.this, "Invalid email, please enter a correct email.", Toast.LENGTH_SHORT).show();
                return; // Stop further execution
            }

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(login.this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            } else {
                // Redirect to ProfileActivity
                Intent intent = new Intent(login.this, Profile.class);
                startActivity(intent);
                Toast.makeText(login.this, "Login successful!", Toast.LENGTH_SHORT).show();
            }
        });

        // Sign Up Text
        TextView signUpText = new TextView(this);
        signUpText.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        signUpText.setText("New user? Sign Up");
        signUpText.setTextColor(Color.BLACK);
        signUpText.setGravity(Gravity.CENTER_HORIZONTAL);
        ((LinearLayout.LayoutParams) signUpText.getLayoutParams()).setMargins(0, 8, 0, 0);
        linearLayout.addView(signUpText);

        // Set the layout as the content view
        setContentView(linearLayout);
    }
}
