package com.example.finalapplication2024;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class forgotpass extends AppCompatActivity {

    private EditText newEmailEditText, newPasswordEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpass);

        // Initialize views
        newEmailEditText = findViewById(R.id.newEmail);
        newPasswordEditText = findViewById(R.id.newPassword);
        submitButton = findViewById(R.id.submitButton);

        // Set click listener for submit button
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEmail = newEmailEditText.getText().toString().trim();
                String newPassword = newPasswordEditText.getText().toString().trim();

                if (newEmail.isEmpty() || newPassword.isEmpty()) {
                    Toast.makeText(forgotpass.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                } else {
                    // Perform any necessary validation or updates here
                    // For example, you can update the email and password in your database.

                    // Redirect to login activity
                    Intent intent = new Intent(forgotpass.this, login.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}